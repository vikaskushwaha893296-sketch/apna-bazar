const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const {
  getListings,
  getListingById,
  createListing,
  deleteListing,
} = require('../controllers/listingController');

router.get('/', getListings);
router.get('/:id', getListingById);
router.post('/', upload.single('image'), createListing);
router.delete('/:id', deleteListing);

module.exports = router;
