const Listing = require('../models/Listing');

// GET /api/listings?search=&category=
exports.getListings = async (req, res) => {
  try {
    const { search, category } = req.query;
    const query = {};
    if (category && category !== 'all') query.category = category;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }
    const listings = await Listing.find(query).sort({ createdAt: -1 });
    res.json(listings);
  } catch (err) {
    res.status(500).json({ message: 'Could not fetch listings', error: err.message });
  }
};

// GET /api/listings/:id
exports.getListingById = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);
    if (!listing) return res.status(404).json({ message: 'Listing not found' });
    res.json(listing);
  } catch (err) {
    res.status(500).json({ message: 'Could not fetch listing', error: err.message });
  }
};

// POST /api/listings
exports.createListing = async (req, res) => {
  try {
    const { title, description, price, category, location, posterName } = req.body;
    if (!title || !description || price === undefined || !category || !location || !posterName) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    const imageUrl = req.file ? req.file.path : '';
    const listing = await Listing.create({
      title, description, price, category, location, posterName, imageUrl,
    });
    res.status(201).json(listing);
  } catch (err) {
    res.status(500).json({ message: 'Could not create listing', error: err.message });
  }
};

// DELETE /api/listings/:id
exports.deleteListing = async (req, res) => {
  try {
    const listing = await Listing.findByIdAndDelete(req.params.id);
    if (!listing) return res.status(404).json({ message: 'Listing not found' });
    res.json({ message: 'Listing deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Could not delete listing', error: err.message });
  }
};
