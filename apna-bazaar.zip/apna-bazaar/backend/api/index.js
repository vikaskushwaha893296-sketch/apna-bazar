require('dotenv').config();
const mongoose = require('mongoose');
const app = require('../app');

// Reuse the same DB connection across warm serverless invocations
let connectionPromise = null;
function ensureDB() {
  if (!connectionPromise) {
    connectionPromise = mongoose.connect(process.env.MONGO_URI);
  }
  return connectionPromise;
}

module.exports = async (req, res) => {
  try {
    await ensureDB();
  } catch (err) {
    res.status(500).json({ message: 'Database connection failed', error: err.message });
    return;
  }
  return app(req, res);
};
