# Apna Bazaar

OLX-style classifieds marketplace — MERN stack (MongoDB, Express, React, Node.js) with real image uploads via Cloudinary.

## Features
- Post an ad with photo, title, category, price, description, location, and your name
- Real image upload (stored on Cloudinary, not on your server)
- Search ads by keyword
- Filter by 10 categories
- Data stored permanently in MongoDB

## Project structure
```
apna-bazaar/
├── backend/          Express API + MongoDB + Cloudinary
│   ├── config/       DB and Cloudinary connection setup
│   ├── models/       Mongoose schema for a listing
│   ├── controllers/  Route logic (create, fetch, delete)
│   ├── routes/       API route definitions
│   ├── middleware/   Multer + Cloudinary upload handler
│   └── server.js     App entry point
└── frontend/         React app (built with Vite)
    └── src/
        ├── components/  Navbar, CategoryChips, ListingCard, PostAdModal, Toast
        ├── data/        Category list
        ├── api.js       All backend API calls
        └── App.jsx      Main page
```

## 1. Prerequisites
- Node.js 18+ installed
- A free MongoDB Atlas account → https://www.mongodb.com/cloud/atlas (create a cluster, copy the connection string)
- A free Cloudinary account → https://cloudinary.com (copy Cloud Name, API Key, API Secret from your dashboard)

## 2. Backend setup
```bash
cd backend
npm install
cp .env.example .env
```
Open `.env` and fill in:
```
MONGO_URI=<your MongoDB Atlas connection string>
CLOUDINARY_CLOUD_NAME=<your cloud name>
CLOUDINARY_API_KEY=<your api key>
CLOUDINARY_API_SECRET=<your api secret>
CLIENT_URL=http://localhost:5173
```
Run it:
```bash
npm run dev
```
API will start at `http://localhost:5000`.

## 3. Frontend setup
Open a new terminal:
```bash
cd frontend
npm install
cp .env.example .env
```
`.env` already points to `http://localhost:5000/api` — change it later when you deploy the backend.

Run it:
```bash
npm run dev
```
App opens at `http://localhost:5173`.

## 4. API reference
| Method | Endpoint            | Description                     |
|--------|---------------------|----------------------------------|
| GET    | /api/listings        | List ads (`?search=&category=`) |
| GET    | /api/listings/:id    | Get one ad                      |
| POST   | /api/listings        | Create ad (multipart/form-data, field `image` for the photo) |
| DELETE | /api/listings/:id    | Delete an ad                    |

## 5. Deploying on Vercel

Vercel only runs serverless functions, not a long-lived Express server — so the backend has a small `api/index.js` entry point and a `vercel.json` already set up for this. You'll create **two separate Vercel projects** from this same folder (or same GitHub repo): one for the backend, one for the frontend.

### Step A — Push to GitHub
Push this whole `apna-bazaar` folder to a GitHub repo (Vercel deploys from Git).

### Step B — Deploy the backend
1. On vercel.com → **Add New Project** → import your repo.
2. Under **Root Directory**, click Edit and select `backend`.
3. Framework Preset: "Other" (it auto-detects the `api/` folder as serverless functions).
4. Add Environment Variables:
   - `MONGO_URI`
   - `CLOUDINARY_CLOUD_NAME`
   - `CLOUDINARY_API_KEY`
   - `CLOUDINARY_API_SECRET`
   - `CLIENT_URL` — leave blank for now, you'll set it after Step C
5. Deploy. Copy the resulting URL, e.g. `https://apna-bazaar-backend.vercel.app`.

### Step C — Deploy the frontend
1. **Add New Project** again → same repo → **Root Directory** → select `frontend`.
2. Framework Preset: Vite (auto-detected). Build command `npm run build`, output directory `dist` (both auto-filled).
3. Add Environment Variable:
   - `VITE_API_URL` = `https://apna-bazaar-backend.vercel.app/api` (your backend URL from Step B, with `/api` at the end)
4. Deploy. Copy this URL too, e.g. `https://apna-bazaar.vercel.app`.

### Step D — Connect them
1. Go back to the **backend** project → Settings → Environment Variables.
2. Set `CLIENT_URL` = `https://apna-bazaar.vercel.app` (your frontend URL from Step C).
3. Redeploy the backend (Deployments tab → ⋯ → Redeploy) so CORS picks up the change.

Your marketplace is now live at the frontend URL, backed by MongoDB Atlas and Cloudinary.

**Note:** on Vercel's free (Hobby) plan, function request bodies are capped around 4.5MB — that's why the image upload limit in `middleware/upload.js` is set to 4MB.

## 6. Notes
- There's no login system yet — anyone can post or delete an ad. Add authentication (e.g. JWT) before using this in production.
- Categories are hardcoded in `frontend/src/data/categories.js` and mirrored in `backend/models/Listing.js` — edit both if you add/remove a category.
