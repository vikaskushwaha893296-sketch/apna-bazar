import { catMap } from '../data/categories';

export default function ListingCard({ listing, onDelete }) {
  const cat = catMap[listing.category] || catMap.others;
  return (
    <div className="card">
      <div className="card-header">
        {listing.imageUrl ? (
          <img src={listing.imageUrl} alt={listing.title} className="card-img" />
        ) : (
          <span className="card-emoji">{cat.emoji}</span>
        )}
        <span className="price-tag">
          {listing.price === 0 ? 'FREE' : `₹${Number(listing.price).toLocaleString('en-IN')}`}
        </span>
      </div>
      <div className="card-body">
        <div className="card-title">{listing.title}</div>
        <div className="card-desc">{listing.description}</div>
        <div className="card-meta">
          <span className="card-cat">{cat.label}</span>
          <span>📍 {listing.location}</span>
        </div>
        {onDelete && (
          <button className="card-delete" onClick={() => onDelete(listing._id)}>
            Remove
          </button>
        )}
      </div>
    </div>
  );
}
