import { CATEGORIES } from '../data/categories';

export default function CategoryChips({ active, setActive }) {
  const chips = [{ id: 'all', label: 'All', emoji: '🧺' }, ...CATEGORIES];
  return (
    <div className="cat-scroll">
      {chips.map((c) => (
        <button
          key={c.id}
          className={`chip ${active === c.id ? 'active' : ''}`}
          onClick={() => setActive(c.id)}
        >
          <span>{c.emoji}</span>
          <span>{c.label}</span>
        </button>
      ))}
    </div>
  );
}
