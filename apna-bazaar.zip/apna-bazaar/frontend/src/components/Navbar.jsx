export default function Navbar({ search, setSearch, onPostClick }) {
  return (
    <div className="topbar">
      <div className="topbar-inner">
        <div className="brand">
          Apna<span>Bazaar</span>
        </div>
        <div className="search-wrap">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search for anything..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button className="post-btn" onClick={onPostClick}>
          + Post Ad
        </button>
      </div>
    </div>
  );
}
