import { useState } from 'react';
import { CATEGORIES } from '../data/categories';

const emptyForm = {
  title: '',
  category: 'electronics',
  price: '',
  description: '',
  location: '',
  posterName: '',
};

export default function PostAdModal({ open, onClose, onSubmit }) {
  const [form, setForm] = useState(emptyForm);
  const [image, setImage] = useState(null);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!open) return null;

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { title, category, price, description, location, posterName } = form;
    if (!title || !category || price === '' || !description || !location || !posterName) {
      setError('Please fill in every field.');
      return;
    }
    setError('');
    setSubmitting(true);

    const data = new FormData();
    Object.entries(form).forEach(([key, value]) => data.append(key, value));
    if (image) data.append('image', image);

    try {
      await onSubmit(data);
      setForm(emptyForm);
      setImage(null);
    } catch (err) {
      setError('Could not publish right now. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="overlay open" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <h2>Post your ad</h2>
        <p className="sub">Free, and live for everyone browsing Apna Bazaar right now.</p>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Photo</label>
            <input type="file" accept="image/*" onChange={(e) => setImage(e.target.files[0])} />
          </div>
          <div className="field">
            <label>Title</label>
            <input
              name="title"
              value={form.title}
              onChange={handleChange}
              maxLength={70}
              placeholder="e.g. iPhone 13, barely used"
            />
          </div>
          <div className="row2">
            <div className="field">
              <label>Category</label>
              <select name="category" value={form.category} onChange={handleChange}>
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.emoji} {c.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Price (₹)</label>
              <input
                name="price"
                type="number"
                min="0"
                value={form.price}
                onChange={handleChange}
                placeholder="0 for free"
              />
            </div>
          </div>
          <div className="field">
            <label>Description</label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              maxLength={300}
              placeholder="Condition, age, why you're selling..."
            />
          </div>
          <div className="row2">
            <div className="field">
              <label>Location</label>
              <input
                name="location"
                value={form.location}
                onChange={handleChange}
                placeholder="e.g. Andheri, Mumbai"
              />
            </div>
            <div className="field">
              <label>Your name</label>
              <input
                name="posterName"
                value={form.posterName}
                onChange={handleChange}
                placeholder="How buyers will see you"
              />
            </div>
          </div>
          {error && <div className="field-error">{error}</div>}
          <div className="modal-actions">
            <button type="button" className="btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={submitting}>
              {submitting ? 'Publishing...' : 'Publish ad'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
