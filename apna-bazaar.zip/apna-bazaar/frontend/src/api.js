import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const fetchListings = (params) =>
  axios.get(`${API_URL}/listings`, { params }).then((res) => res.data);

export const createListing = (formData) =>
  axios
    .post(`${API_URL}/listings`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    .then((res) => res.data);

export const deleteListing = (id) =>
  axios.delete(`${API_URL}/listings/${id}`).then((res) => res.data);
