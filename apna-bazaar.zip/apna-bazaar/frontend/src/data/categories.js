export const CATEGORIES = [
  { id: 'electronics', label: 'Electronics', emoji: '⚡' },
  { id: 'mobiles', label: 'Mobiles', emoji: '📱' },
  { id: 'vehicles', label: 'Vehicles', emoji: '🚗' },
  { id: 'furniture', label: 'Furniture', emoji: '🛋️' },
  { id: 'fashion', label: 'Fashion', emoji: '👕' },
  { id: 'property', label: 'Property', emoji: '🏠' },
  { id: 'jobs', label: 'Jobs', emoji: '💼' },
  { id: 'books', label: 'Books', emoji: '📚' },
  { id: 'sports', label: 'Sports', emoji: '⚽' },
  { id: 'others', label: 'Others', emoji: '🏷️' },
];

export const catMap = Object.fromEntries(CATEGORIES.map((c) => [c.id, c]));
