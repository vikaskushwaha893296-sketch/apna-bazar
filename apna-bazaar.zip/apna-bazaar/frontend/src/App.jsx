import { useEffect, useState, useCallback } from 'react';
import Navbar from './components/Navbar';
import CategoryChips from './components/CategoryChips';
import ListingCard from './components/ListingCard';
import PostAdModal from './components/PostAdModal';
import Toast from './components/Toast';
import { fetchListings, createListing } from './api';

export default function App() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '' });

  const showToast = (message) => {
    setToast({ show: true, message });
    setTimeout(() => setToast({ show: false, message: '' }), 2200);
  };

  const loadListings = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchListings({ search, category });
      setListings(data);
    } catch (err) {
      showToast('Could not load listings');
    } finally {
      setLoading(false);
    }
  }, [search, category]);

  useEffect(() => {
    const t = setTimeout(loadListings, 300); // debounce search typing
    return () => clearTimeout(t);
  }, [loadListings]);

  const handlePost = async (formData) => {
    await createListing(formData);
    setModalOpen(false);
    showToast('✅ Ad published — visible to everyone');
    loadListings();
  };

  return (
    <div>
      <Navbar search={search} setSearch={setSearch} onPostClick={() => setModalOpen(true)} />
      <div className="app">
        <CategoryChips active={category} setActive={setCategory} />
        <div className="status-line">
          <span>
            {loading
              ? 'Loading listings...'
              : `${listings.length} ad${listings.length === 1 ? '' : 's'} live right now`}
          </span>
        </div>
        <div className="grid">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton" />)
          ) : listings.length === 0 ? (
            <div className="empty">
              <div className="empty-emoji">🗂️</div>
              <h3>Nothing here yet</h3>
              <p>Be the first to post an ad on Apna Bazaar.</p>
            </div>
          ) : (
            listings.map((l) => <ListingCard key={l._id} listing={l} />)
          )}
        </div>
      </div>
      <PostAdModal open={modalOpen} onClose={() => setModalOpen(false)} onSubmit={handlePost} />
      <Toast message={toast.message} show={toast.show} />
    </div>
  );
}
